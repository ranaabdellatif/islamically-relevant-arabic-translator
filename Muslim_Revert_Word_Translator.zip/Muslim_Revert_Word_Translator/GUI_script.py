import tkinter as tk

class MyGUI:


    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Islamically-Relevant Arabic Words Translator")
        self.label = tk.Label(self.root , bg='#9cd991', fg='white', text="Alsalam Alaykum!", font=('Arial',20))
        self.label.pack(padx=30,pady=30)

        self.intro = tk.Label(self.root, text='Please enter the word you would like translated below!', height = 5, font = ('Arial', 15))
        self.intro.pack(padx=10, pady=10)

        self.check_state = tk.StringVar()
        self.check = tk.Entry(self.root, text='Type here', bg='#9cd991', fg='white', highlightcolor='red', font=('Arial',16))
        self.check.pack(padx=20,pady=20)

        self.button = tk.Button(self.root, text=("Enter"), font=('Arial',16))
        self.button.pack(padx=20,pady=20)
        # command=self.retrieve_message


    #def retrieve_message(self):
        #print(self.check.get())

        self.user_input = self.check.get()


   # def output_info(self):

        self.root.mainloop()

#--main--

gui = MyGUI
print(f'oml: {gui.user_input}')

