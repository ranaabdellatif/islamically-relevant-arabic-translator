import tkinter as tk

root = tk.Tk()
root.title("Islamically-Relevant Arabic Words Translator")
label = tk.Label(root , bg='#9cd991', fg='white', text="Alsalam Alaykum!", font=('Arial',20))
label.pack(padx=30,pady=30)
intro = tk.Label(root, text='Please enter the word you would like translated below!', height = 5, font = ('Arial', 15))
intro.pack(padx=10, pady=10)

check_state = tk.StringVar()
check = tk.Entry(root, text='Type here', bg='#9cd991', fg='white', highlightcolor='red', font=('Arial',16))
check.pack(padx=20,pady=20)

button = tk.Button(root, text=("Enter"), font=('Arial',16), command=check.get())
button.pack(padx=20,pady=20)
        # command=self.retrieve_message


    #def retrieve_message(self):
        #print(self.check.get())
user_input = check.get()

button.invoke()
   # def output_info(self):
root.mainloop()

print(f'TEST: {user_input}')