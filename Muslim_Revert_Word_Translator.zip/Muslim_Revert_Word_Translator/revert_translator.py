"""translations = []
arabic_word = []
english_translation =[]
context = []


with open("arabic_words.txt" , 'r') as a_file:
    for line in a_file:
        translations.append(line.strip().split(","))

for i in range(len(translations)-1):
    arabic_word.append(translations[i][0])
    english_translation.append(translations[i][1])
    context.append(translations[i][2])


user_word = input("Salam Alaykum! Enter the word you would like translated: ")
user_word.lower()
if user_word in arabic_word:
    for i in range(len(translations)):
        if user_word == translations[i][0]:
            print(f'Given word: {user_word} \nTranslation:{translations[i][1]} \nContext:{translations[i][2]} ')

"""
translations = []
arabic_word = []
english_translation = []
context = []

with open("arabic_words.txt", 'r') as a_file:
    for line in a_file:
        translations.append(line.strip().split(","))

#for i in range(len(translations)):
    #print (translations[i])

for i in range(len(translations)):
    arabic_word.append(translations[i][0])
    english_translation.append(translations[i][1])
    context.append(translations[i][2])

user_word = input("Salam Alaykum! Enter the word you would like translated: ")
user_word = user_word.lower()  # Remember to assign the lowercased value back to the variable

if user_word in arabic_word:
    for i in range(len(translations)):
        if user_word == translations[i][0]:
            print(f'Given word: {user_word} \nTranslation: {translations[i][1]} \nContext: {translations[i][2]}')
