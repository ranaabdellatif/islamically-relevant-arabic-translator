"""
Islamically Relevant Arabic Translator

This program was designed to assist new revert Muslims or non-Arabic speaking Muslims
to understand Arabic terminology that is used in context of the religion.

Tkinter is used for the GUI for a more aesthetically pleasing experience.

Developer: ranran645

"""

import tkinter as tk

#function to translate the word
def translate_word():
    user_word = check.get().lower()  # Get the user input and convert it to lowercase

    translations = []
    arabic_word = []
    english_translation = []
    context = []

    #using txt file I put together containing most ocmon words / definitions
    with open("arabic_words.txt", 'r') as a_file:
        for line in a_file:
            translations.append(line.strip().split(","))

    for translation in translations:
        arabic_word.append(translation[0])
        english_translation.append(translation[1])
        context.append(translation[2])

    if user_word in arabic_word:
        for i in range(len(translations)):
            if user_word == translations[i][0]:
                translation_label.config(text=f"Given word: {user_word}\nTranslation: {translations[i][1]}\nContext: {translations[i][2]}")
    else:
        translation_label.config(text="Translation not found for the given word.")


#Formatting for GUI
root = tk.Tk()
root.title("Islamically-Relevant Arabic Words Translator")
label = tk.Label(root, bg='#9cd991', fg='white', text="Alsalam Alaykum!", font=('Arial', 20))
label.pack(padx=30, pady=30)
intro = tk.Label(root, text='Please enter the word you would like translated below!', height=5, font=('Arial', 15))
intro.pack(padx=10, pady=10)

check = tk.Entry(root, text='Type here', bg='#9cd991', fg='white', highlightcolor='red', font=('Arial', 16))
check.pack(padx=20, pady=20)

button = tk.Button(root, text="Enter", font=('Arial', 16), command=translate_word)
button.pack(padx=20, pady=20)

translation_label = tk.Label(root, bg='#9cd991', fg='white', text="", font=('Arial', 15))
translation_label.pack(padx=10, pady=10)

root.mainloop()
